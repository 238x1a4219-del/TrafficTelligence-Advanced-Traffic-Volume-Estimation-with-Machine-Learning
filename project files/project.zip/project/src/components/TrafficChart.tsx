import React, { useState, useEffect } from 'react';

export function TrafficChart() {
  const [data, setData] = useState<number[]>([]);
  const [timeLabels, setTimeLabels] = useState<string[]>([]);

  useEffect(() => {
    // Generate initial data
    const initialData = Array.from({ length: 24 }, (_, i) => {
      const hour = i;
      // Simulate traffic patterns: higher during rush hours
      const baseTraffic = Math.sin((hour - 6) * Math.PI / 12) * 30 + 50;
      const rushHourBoost = (hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19) ? 40 : 0;
      return Math.max(10, baseTraffic + rushHourBoost + Math.random() * 20);
    });
    
    const labels = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`);
    
    setData(initialData);
    setTimeLabels(labels);

    // Update data every 30 seconds
    const interval = setInterval(() => {
      setData(prevData => 
        prevData.map(value => Math.max(10, value + (Math.random() * 10 - 5)))
      );
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const maxValue = Math.max(...data);

  return (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-white">24-Hour Traffic Volume</h3>
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-gray-400">Vehicle Count</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-gray-400">ML Prediction</span>
          </div>
        </div>
      </div>
      
      <div className="relative h-64">
        <svg width="100%" height="100%" className="overflow-visible">
          {/* Grid lines */}
          {[0, 25, 50, 75, 100].map((percent) => (
            <line
              key={percent}
              x1="0"
              y1={`${100 - percent}%`}
              x2="100%"
              y2={`${100 - percent}%`}
              stroke="#374151"
              strokeWidth="1"
              strokeDasharray="2,2"
            />
          ))}
          
          {/* Data line */}
          <polyline
            points={data.map((value, index) => 
              `${(index / (data.length - 1)) * 100}%, ${100 - (value / maxValue) * 100}%`
            ).join(' ')}
            fill="none"
            stroke="#3B82F6"
            strokeWidth="2"
            className="drop-shadow-sm"
          />
          
          {/* ML Prediction line (slightly ahead) */}
          <polyline
            points={data.map((value, index) => 
              `${(index / (data.length - 1)) * 100}%, ${100 - ((value * 1.1) / maxValue) * 100}%`
            ).join(' ')}
            fill="none"
            stroke="#10B981"
            strokeWidth="2"
            strokeDasharray="5,5"
            opacity="0.7"
          />
          
          {/* Data points */}
          {data.map((value, index) => (
            <circle
              key={index}
              cx={`${(index / (data.length - 1)) * 100}%`}
              cy={`${100 - (value / maxValue) * 100}%`}
              r="3"
              fill="#3B82F6"
              className="hover:r-5 cursor-pointer transition-all"
            />
          ))}
        </svg>
        
        {/* X-axis labels */}
        <div className="absolute -bottom-6 left-0 right-0 flex justify-between text-xs text-gray-400">
          {timeLabels.filter((_, index) => index % 4 === 0).map((label, index) => (
            <span key={index}>{label}</span>
          ))}
        </div>
      </div>
    </div>
  );
}