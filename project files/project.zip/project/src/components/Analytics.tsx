import React, { useState } from 'react';
import { Calendar, Download, Filter, TrendingUp } from 'lucide-react';

export function Analytics() {
  const [selectedTimeframe, setSelectedTimeframe] = useState('7d');
  const [selectedMetric, setSelectedMetric] = useState('volume');

  const timeframes = [
    { value: '24h', label: 'Last 24 Hours' },
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 3 Months' }
  ];

  const metrics = [
    { value: 'volume', label: 'Traffic Volume' },
    { value: 'speed', label: 'Average Speed' },
    { value: 'congestion', label: 'Congestion Index' },
    { value: 'incidents', label: 'Incident Count' }
  ];

  const analyticsData = {
    volume: {
      current: 156789,
      previous: 142356,
      change: 10.1,
      trend: 'up'
    },
    speed: {
      current: 45.3,
      previous: 43.8,
      change: 3.4,
      trend: 'up'
    },
    congestion: {
      current: 2.4,
      previous: 2.8,
      change: -14.3,
      trend: 'down'
    },
    incidents: {
      current: 23,
      previous: 31,
      change: -25.8,
      trend: 'down'
    }
  };

  const currentData = analyticsData[selectedMetric as keyof typeof analyticsData];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Traffic Analytics</h2>
        <div className="flex items-center space-x-4">
          <select 
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
            className="bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-white"
          >
            {timeframes.map(tf => (
              <option key={tf.value} value={tf.value}>{tf.label}</option>
            ))}
          </select>
          <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Metric Selection */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {metrics.map(metric => (
          <button
            key={metric.value}
            onClick={() => setSelectedMetric(metric.value)}
            className={`p-4 rounded-lg border transition-colors ${
              selectedMetric === metric.value 
                ? 'bg-blue-600 border-blue-500' 
                : 'bg-gray-800 border-gray-600 hover:border-gray-500'
            }`}
          >
            <div className="text-left">
              <p className="text-gray-400 text-sm">{metric.label}</p>
              <p className="text-2xl font-bold text-white mt-1">
                {analyticsData[metric.value as keyof typeof analyticsData].current}
                {metric.value === 'speed' ? ' mph' : ''}
                {metric.value === 'congestion' ? '/5' : ''}
              </p>
              <div className={`flex items-center mt-2 text-sm ${
                analyticsData[metric.value as keyof typeof analyticsData].trend === 'up' 
                  ? 'text-green-400' 
                  : 'text-red-400'
              }`}>
                <TrendingUp className={`h-4 w-4 mr-1 ${
                  analyticsData[metric.value as keyof typeof analyticsData].trend === 'down' 
                    ? 'rotate-180' 
                    : ''
                }`} />
                <span>
                  {analyticsData[metric.value as keyof typeof analyticsData].change > 0 ? '+' : ''}
                  {analyticsData[metric.value as keyof typeof analyticsData].change}%
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Main Chart Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold">{metrics.find(m => m.value === selectedMetric)?.label} Trends</h3>
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span className="text-gray-400">Current Period</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-400">Previous Period</span>
              </div>
            </div>
          </div>
          
          {/* Simulated chart area */}
          <div className="h-64 bg-gray-700 rounded-lg flex items-center justify-center">
            <div className="text-center text-gray-400">
              <Calendar className="h-16 w-16 mx-auto mb-4 opacity-50" />
              <p>Interactive chart displaying {selectedMetric} data for {selectedTimeframe}</p>
              <p className="text-sm mt-2">Trend: {currentData.change > 0 ? 'Increasing' : 'Decreasing'} by {Math.abs(currentData.change)}%</p>
            </div>
          </div>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h3 className="text-lg font-semibold mb-4">Key Insights</h3>
            <div className="space-y-3">
              <div className="p-3 bg-blue-900/30 rounded-lg border border-blue-700">
                <p className="text-blue-300 font-medium">Peak Hours</p>
                <p className="text-gray-300 text-sm">7-9 AM, 5-7 PM show highest traffic volume</p>
              </div>
              <div className="p-3 bg-green-900/30 rounded-lg border border-green-700">
                <p className="text-green-300 font-medium">Efficiency</p>
                <p className="text-gray-300 text-sm">Overall traffic flow improved by 12% this month</p>
              </div>
              <div className="p-3 bg-orange-900/30 rounded-lg border border-orange-700">
                <p className="text-orange-300 font-medium">Prediction</p>
                <p className="text-gray-300 text-sm">Weekend traffic expected to increase by 15%</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h3 className="text-lg font-semibold mb-4">Report Summary</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Period:</span>
                <span className="text-white">{timeframes.find(tf => tf.value === selectedTimeframe)?.label}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Data Points:</span>
                <span className="text-white">1,247,892</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Accuracy:</span>
                <span className="text-green-400">94.2%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Coverage:</span>
                <span className="text-white">127 locations</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}