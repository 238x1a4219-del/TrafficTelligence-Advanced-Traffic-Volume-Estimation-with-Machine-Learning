import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Clock, MapPin } from 'lucide-react';

interface FeedItem {
  id: string;
  type: 'incident' | 'congestion' | 'normal' | 'maintenance';
  location: string;
  message: string;
  time: string;
  severity: 'high' | 'medium' | 'low';
}

export function LiveFeed() {
  const [feedItems, setFeedItems] = useState<FeedItem[]>([
    {
      id: '1',
      type: 'incident',
      location: 'I-95 North Mile 45',
      message: 'Vehicle breakdown reported in right lane',
      time: '2 min ago',
      severity: 'high'
    },
    {
      id: '2',
      type: 'congestion',
      location: 'Downtown District',
      message: 'Heavy traffic detected, 15% above normal',
      time: '5 min ago',
      severity: 'medium'
    },
    {
      id: '3',
      type: 'normal',
      location: 'Highway 101',
      message: 'Traffic flow normalized',
      time: '8 min ago',
      severity: 'low'
    },
    {
      id: '4',
      type: 'maintenance',
      location: 'Bridge Street',
      message: 'Scheduled maintenance completed',
      time: '12 min ago',
      severity: 'low'
    }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      const newItem: FeedItem = {
        id: Date.now().toString(),
        type: ['incident', 'congestion', 'normal'][Math.floor(Math.random() * 3)] as any,
        location: ['I-95 South', 'Main Street', 'Central Ave', 'Highway 101'][Math.floor(Math.random() * 4)],
        message: 'New traffic update detected',
        time: 'Just now',
        severity: ['high', 'medium', 'low'][Math.floor(Math.random() * 3)] as any
      };

      setFeedItems(prev => [newItem, ...prev.slice(0, 9)]);
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const getIcon = (type: string) => {
    switch (type) {
      case 'incident':
        return AlertTriangle;
      case 'congestion':
        return Clock;
      case 'normal':
        return CheckCircle;
      case 'maintenance':
        return MapPin;
      default:
        return AlertTriangle;
    }
  };

  const getColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'text-red-400';
      case 'medium':
        return 'text-yellow-400';
      case 'low':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Live Traffic Feed</h3>
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
      </div>
      
      <div className="space-y-3 max-h-80 overflow-y-auto">
        {feedItems.map((item) => {
          const Icon = getIcon(item.type);
          return (
            <div key={item.id} className="flex items-start space-x-3 p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors">
              <Icon className={`h-5 w-5 mt-0.5 ${getColor(item.severity)}`} />
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium">{item.location}</p>
                <p className="text-gray-300 text-xs mt-1">{item.message}</p>
                <p className="text-gray-400 text-xs mt-1">{item.time}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}