import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Database, Zap, Shield, User } from 'lucide-react';

export function Settings() {
  const [activeSection, setActiveSection] = useState('notifications');
  const [notifications, setNotifications] = useState({
    highTraffic: true,
    incidents: true,
    modelUpdates: false,
    reports: true
  });

  const sections = [
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'data', label: 'Data Sources', icon: Database },
    { id: 'ml', label: 'ML Models', icon: Zap },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'notifications':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Notification Preferences</h3>
            
            <div className="space-y-4">
              {[
                { key: 'highTraffic', label: 'High Traffic Alerts', description: 'Get notified when traffic volume exceeds normal levels' },
                { key: 'incidents', label: 'Traffic Incidents', description: 'Immediate alerts for accidents and road closures' },
                { key: 'modelUpdates', label: 'ML Model Updates', description: 'Notifications about model retraining and improvements' },
                { key: 'reports', label: 'Report Generation', description: 'Alert when scheduled reports are ready' }
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                  <div>
                    <p className="text-white font-medium">{item.label}</p>
                    <p className="text-gray-400 text-sm">{item.description}</p>
                  </div>
                  <button
                    onClick={() => setNotifications(prev => ({ ...prev, [item.key]: !prev[item.key as keyof typeof prev] }))}
                    className={`w-12 h-6 rounded-full transition-colors ${
                      notifications[item.key as keyof typeof notifications] ? 'bg-blue-600' : 'bg-gray-600'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      notifications[item.key as keyof typeof notifications] ? 'translate-x-6' : 'translate-x-1'
                    }`}></div>
                  </button>
                </div>
              ))}
            </div>
          </div>
        );

      case 'data':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Data Source Configuration</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { name: 'Traffic Cameras', status: 'Connected', count: '47 devices' },
                { name: 'Loop Detectors', status: 'Connected', count: '123 sensors' },
                { name: 'GPS Data', status: 'Connected', count: '~50k vehicles' },
                { name: 'Weather Service', status: 'Connected', count: '12 stations' },
                { name: 'Incident Reports', status: 'Connected', count: 'Live feed' },
                { name: 'Public Transit', status: 'Disconnected', count: '0 feeds' }
              ].map((source) => (
                <div key={source.name} className="p-4 bg-gray-700 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-white font-medium">{source.name}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      source.status === 'Connected' 
                        ? 'bg-green-900/30 text-green-400' 
                        : 'bg-red-900/30 text-red-400'
                    }`}>
                      {source.status}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm">{source.count}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 'ml':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Machine Learning Configuration</h3>
            
            <div className="space-y-4">
              <div className="p-4 bg-gray-700 rounded-lg">
                <h4 className="text-white font-medium mb-2">Traffic Volume Prediction</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Model:</span>
                    <span className="text-white ml-2">LSTM Neural Network</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Accuracy:</span>
                    <span className="text-green-400 ml-2">94.2%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Last Training:</span>
                    <span className="text-white ml-2">2 days ago</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Next Update:</span>
                    <span className="text-blue-400 ml-2">In 5 days</span>
                  </div>
                </div>
                <button className="mt-3 bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-sm transition-colors">
                  Retrain Model
                </button>
              </div>

              <div className="p-4 bg-gray-700 rounded-lg">
                <h4 className="text-white font-medium mb-2">Anomaly Detection</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Algorithm:</span>
                    <span className="text-white ml-2">Isolation Forest</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Sensitivity:</span>
                    <span className="text-orange-400 ml-2">Medium</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Detected Today:</span>
                    <span className="text-white ml-2">3 anomalies</span>
                  </div>
                  <div>
                    <span className="text-gray-400">False Positive Rate:</span>
                    <span className="text-green-400 ml-2">2.1%</span>
                  </div>
                </div>
                <div className="mt-3 flex space-x-2">
                  <button className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded text-sm transition-colors">
                    Low
                  </button>
                  <button className="bg-orange-600 hover:bg-orange-700 px-3 py-1 rounded text-sm transition-colors">
                    Medium
                  </button>
                  <button className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded text-sm transition-colors">
                    High
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Security Settings</h3>
            
            <div className="space-y-4">
              <div className="p-4 bg-gray-700 rounded-lg">
                <h4 className="text-white font-medium mb-3">Access Control</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Two-Factor Authentication</span>
                    <span className="text-green-400">Enabled</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Session Timeout</span>
                    <span className="text-white">4 hours</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">API Rate Limiting</span>
                    <span className="text-green-400">Enabled</span>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-gray-700 rounded-lg">
                <h4 className="text-white font-medium mb-3">Data Privacy</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Data Encryption</span>
                    <span className="text-green-400">AES-256</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Data Retention</span>
                    <span className="text-white">90 days</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Anonymization</span>
                    <span className="text-green-400">Enabled</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'profile':
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">Profile Settings</h3>
            
            <div className="space-y-4">
              <div className="p-4 bg-gray-700 rounded-lg">
                <h4 className="text-white font-medium mb-3">Account Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-gray-400 text-sm mb-1">Full Name</label>
                    <input 
                      type="text" 
                      defaultValue="Traffic Administrator"
                      className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-1">Email</label>
                    <input 
                      type="email" 
                      defaultValue="admin@traffictelligence.com"
                      className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-1">Role</label>
                    <select className="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2 text-white">
                      <option>System Administrator</option>
                      <option>Traffic Analyst</option>
                      <option>Operations Manager</option>
                    </select>
                  </div>
                </div>
                <button className="mt-4 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded transition-colors">
                  Update Profile
                </button>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <SettingsIcon className="h-8 w-8 text-gray-400" />
        <h2 className="text-3xl font-bold">Settings</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <div className="lg:col-span-1">
          <nav className="bg-gray-800 rounded-lg border border-gray-700 p-4">
            <ul className="space-y-2">
              {sections.map((section) => {
                const Icon = section.icon;
                return (
                  <li key={section.id}>
                    <button
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                        activeSection === section.id
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{section.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          <div className="bg-gray-800 rounded-lg border border-gray-700 p-6">
            {renderContent()}
          </div>
        </div>
      </div>
    </div>
  );
}