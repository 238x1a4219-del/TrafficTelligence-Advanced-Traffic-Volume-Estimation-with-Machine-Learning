import React, { useState } from 'react';
import { FileText, Download, Calendar, Filter, Eye, Plus } from 'lucide-react';

export function Reports() {
  const [selectedReport, setSelectedReport] = useState<string | null>(null);

  const reports = [
    {
      id: '1',
      name: 'Weekly Traffic Summary',
      type: 'Summary Report',
      date: '2025-01-20',
      status: 'Ready',
      size: '2.4 MB',
      description: 'Comprehensive analysis of traffic patterns for the week of Jan 13-20, 2025'
    },
    {
      id: '2',
      name: 'ML Model Performance Q1',
      type: 'Technical Report',
      date: '2025-01-18',
      status: 'Ready',
      size: '1.8 MB',
      description: 'Machine learning model accuracy and performance metrics for Q1 2025'
    },
    {
      id: '3',
      name: 'Incident Analysis December',
      type: 'Incident Report',
      date: '2025-01-15',
      status: 'Ready',
      size: '3.1 MB',
      description: 'Detailed analysis of traffic incidents and their impact in December 2024'
    },
    {
      id: '4',
      name: 'Peak Hour Optimization',
      type: 'Optimization Report',
      date: '2025-01-12',
      status: 'Processing',
      size: '-',
      description: 'Strategic recommendations for peak hour traffic management'
    },
    {
      id: '5',
      name: 'Monthly Congestion Trends',
      type: 'Trend Analysis',
      date: '2025-01-10',
      status: 'Ready',
      size: '1.5 MB',
      description: 'Monthly analysis of congestion patterns and seasonal variations'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Ready': return 'text-green-400 bg-green-900/30';
      case 'Processing': return 'text-orange-400 bg-orange-900/30';
      case 'Failed': return 'text-red-400 bg-red-900/30';
      default: return 'text-gray-400 bg-gray-900/30';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Traffic Reports</h2>
        <div className="flex items-center space-x-4">
          <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg transition-colors">
            <Plus className="h-4 w-4" />
            <span>Generate Report</span>
          </button>
          <button className="flex items-center space-x-2 bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg transition-colors">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center space-x-3">
            <FileText className="h-8 w-8 text-blue-500" />
            <div>
              <p className="text-2xl font-bold text-white">{reports.length}</p>
              <p className="text-gray-400 text-sm">Total Reports</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center space-x-3">
            <Download className="h-8 w-8 text-green-500" />
            <div>
              <p className="text-2xl font-bold text-white">{reports.filter(r => r.status === 'Ready').length}</p>
              <p className="text-gray-400 text-sm">Ready to Download</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center space-x-3">
            <Calendar className="h-8 w-8 text-orange-500" />
            <div>
              <p className="text-2xl font-bold text-white">{reports.filter(r => r.status === 'Processing').length}</p>
              <p className="text-gray-400 text-sm">Processing</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center space-x-3">
            <Eye className="h-8 w-8 text-purple-500" />
            <div>
              <p className="text-2xl font-bold text-white">8.7 MB</p>
              <p className="text-gray-400 text-sm">Total Size</p>
            </div>
          </div>
        </div>
      </div>

      {/* Reports List */}
      <div className="bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
        <div className="px-6 py-4 bg-gray-700 border-b border-gray-600">
          <h3 className="text-lg font-semibold">Recent Reports</h3>
        </div>
        
        <div className="divide-y divide-gray-700">
          {reports.map((report) => (
            <div 
              key={report.id} 
              className="p-6 hover:bg-gray-700/50 transition-colors cursor-pointer"
              onClick={() => setSelectedReport(selectedReport === report.id ? null : report.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <FileText className="h-6 w-6 text-blue-400" />
                  <div>
                    <h4 className="text-white font-medium">{report.name}</h4>
                    <p className="text-gray-400 text-sm">{report.type}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(report.status)}`}>
                    {report.status}
                  </span>
                  <span className="text-gray-400 text-sm">{report.date}</span>
                  {report.status === 'Ready' && (
                    <button className="flex items-center space-x-1 text-blue-400 hover:text-blue-300">
                      <Download className="h-4 w-4" />
                      <span className="text-sm">{report.size}</span>
                    </button>
                  )}
                </div>
              </div>
              
              {selectedReport === report.id && (
                <div className="mt-4 p-4 bg-gray-700 rounded-lg">
                  <p className="text-gray-300 text-sm mb-4">{report.description}</p>
                  <div className="flex space-x-2">
                    {report.status === 'Ready' && (
                      <>
                        <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-sm transition-colors">
                          <Download className="h-4 w-4" />
                          <span>Download PDF</span>
                        </button>
                        <button className="flex items-center space-x-2 bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded text-sm transition-colors">
                          <Eye className="h-4 w-4" />
                          <span>Preview</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Report Templates */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <h3 className="text-lg font-semibold mb-4">Report Templates</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { name: 'Daily Summary', description: 'Quick overview of daily traffic metrics' },
            { name: 'Weekly Analysis', description: 'Comprehensive weekly traffic analysis' },
            { name: 'Monthly Trends', description: 'Long-term trend analysis and insights' },
            { name: 'Incident Report', description: 'Detailed incident analysis and impact' },
            { name: 'Performance Review', description: 'ML model performance and accuracy' },
            { name: 'Custom Report', description: 'Build your own custom report' }
          ].map((template, index) => (
            <div key={index} className="p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer">
              <h4 className="text-white font-medium">{template.name}</h4>
              <p className="text-gray-400 text-sm mt-1">{template.description}</p>
              <button className="mt-3 text-blue-400 hover:text-blue-300 text-sm font-medium">
                Generate →
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}