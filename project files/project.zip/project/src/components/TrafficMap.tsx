import React, { useState } from 'react';
import { MapPin, Navigation, Zap, AlertTriangle } from 'lucide-react';

export function TrafficMap() {
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  
  const trafficPoints = [
    { id: 'loc1', name: 'I-95 North Junction', x: 25, y: 30, status: 'high', volume: 1247 },
    { id: 'loc2', name: 'Downtown Main St', x: 45, y: 45, status: 'medium', volume: 892 },
    { id: 'loc3', name: 'Highway 101 East', x: 70, y: 25, status: 'low', volume: 456 },
    { id: 'loc4', name: 'Bridge St Intersection', x: 30, y: 70, status: 'high', volume: 1156 },
    { id: 'loc5', name: 'Airport Connector', x: 80, y: 60, status: 'medium', volume: 678 },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-orange-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'high': return AlertTriangle;
      case 'medium': return Navigation;
      case 'low': return MapPin;
      default: return MapPin;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Traffic Flow Map</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>Low Traffic</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
            <span>Moderate Traffic</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span>Heavy Traffic</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Interactive Map */}
        <div className="lg:col-span-3 bg-gray-800 rounded-lg p-6 border border-gray-700">
          <div className="relative bg-gray-700 rounded-lg h-96 overflow-hidden">
            {/* Simulated map background */}
            <div className="absolute inset-0 bg-gradient-to-br from-gray-600 to-gray-800 opacity-50"></div>
            
            {/* Traffic flow lines */}
            <svg className="absolute inset-0 w-full h-full">
              <defs>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                  <feMerge> 
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>
              
              {/* Animated traffic flow lines */}
              <path 
                d="M 100 120 Q 200 100 300 140 T 500 120" 
                stroke="#3B82F6" 
                strokeWidth="3" 
                fill="none"
                filter="url(#glow)"
                className="animate-pulse"
              />
              <path 
                d="M 120 180 Q 250 200 400 160 T 600 180" 
                stroke="#10B981" 
                strokeWidth="3" 
                fill="none"
                filter="url(#glow)"
                className="animate-pulse"
              />
              <path 
                d="M 80 250 Q 300 280 480 240 T 650 260" 
                stroke="#F59E0B" 
                strokeWidth="3" 
                fill="none"
                filter="url(#glow)"
                className="animate-pulse"
              />
            </svg>
            
            {/* Traffic monitoring points */}
            {trafficPoints.map((point) => {
              const StatusIcon = getStatusIcon(point.status);
              return (
                <div
                  key={point.id}
                  className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${point.x}%`, top: `${point.y}%` }}
                  onClick={() => setSelectedLocation(point.id)}
                >
                  <div className={`relative p-2 rounded-full ${getStatusColor(point.status)} animate-pulse`}>
                    <StatusIcon className="h-4 w-4 text-white" />
                    {selectedLocation === point.id && (
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap border border-gray-600">
                        <div className="font-semibold">{point.name}</div>
                        <div>Volume: {point.volume} vehicles/hour</div>
                        <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                      </div>
                    )}
                  </div>
                  <div className={`absolute inset-0 rounded-full ${getStatusColor(point.status)} animate-ping opacity-30`}></div>
                </div>
              );
            })}
            
            {/* Real-time vehicle indicators */}
            <div className="absolute top-4 left-4 flex items-center space-x-2 bg-gray-900/80 px-3 py-2 rounded-lg">
              <Zap className="h-4 w-4 text-yellow-400 animate-pulse" />
              <span className="text-white text-sm font-medium">Live Tracking Active</span>
            </div>
          </div>
        </div>

        {/* Location Details */}
        <div className="space-y-4">
          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h3 className="text-lg font-semibold mb-4">Location Details</h3>
            {selectedLocation ? (
              <div className="space-y-3">
                {trafficPoints.filter(p => p.id === selectedLocation).map(point => (
                  <div key={point.id}>
                    <h4 className="font-medium text-white">{point.name}</h4>
                    <div className="space-y-2 mt-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Status:</span>
                        <span className={`capitalize ${
                          point.status === 'high' ? 'text-red-400' : 
                          point.status === 'medium' ? 'text-orange-400' : 
                          'text-green-400'
                        }`}>
                          {point.status}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Volume:</span>
                        <span className="text-white">{point.volume}/hour</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Prediction:</span>
                        <span className="text-blue-400">
                          {point.status === 'high' ? '+15%' : point.status === 'medium' ? 'Stable' : '-5%'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400">Click on a location marker to view details</p>
            )}
          </div>

          <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
            <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Locations:</span>
                <span className="text-white">{trafficPoints.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">High Traffic:</span>
                <span className="text-red-400">{trafficPoints.filter(p => p.status === 'high').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Moderate Traffic:</span>
                <span className="text-orange-400">{trafficPoints.filter(p => p.status === 'medium').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Low Traffic:</span>
                <span className="text-green-400">{trafficPoints.filter(p => p.status === 'low').length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}