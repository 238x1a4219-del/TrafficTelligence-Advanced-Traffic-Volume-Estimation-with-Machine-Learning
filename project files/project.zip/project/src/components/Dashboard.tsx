import React, { useState, useEffect } from 'react';
import { StatsCard } from './StatsCard';
import { TrafficChart } from './TrafficChart';
import { LiveFeed } from './LiveFeed';
import { MLInsights } from './MLInsights';
import { Car, TrendingUp, AlertTriangle, Clock } from 'lucide-react';

export function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [trafficData, setTrafficData] = useState({
    totalVehicles: 24567,
    avgSpeed: 45.3,
    congestionLevel: 'Moderate',
    incidents: 3
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      // Simulate real-time data updates
      setTrafficData(prev => ({
        totalVehicles: prev.totalVehicles + Math.floor(Math.random() * 20 - 10),
        avgSpeed: Math.max(20, Math.min(80, prev.avgSpeed + (Math.random() * 4 - 2))),
        congestionLevel: prev.avgSpeed < 30 ? 'High' : prev.avgSpeed > 50 ? 'Low' : 'Moderate',
        incidents: Math.max(0, prev.incidents + Math.floor(Math.random() * 3 - 1))
      }));
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const stats = [
    {
      title: 'Total Vehicles Today',
      value: trafficData.totalVehicles.toLocaleString(),
      change: '+12.5%',
      icon: Car,
      color: 'blue'
    },
    {
      title: 'Average Speed',
      value: `${trafficData.avgSpeed.toFixed(1)} mph`,
      change: '+2.3%',
      icon: TrendingUp,
      color: 'green'
    },
    {
      title: 'Congestion Level',
      value: trafficData.congestionLevel,
      change: trafficData.congestionLevel === 'Low' ? 'Good' : trafficData.congestionLevel === 'High' ? 'Critical' : 'Monitor',
      icon: AlertTriangle,
      color: trafficData.congestionLevel === 'Low' ? 'green' : trafficData.congestionLevel === 'High' ? 'red' : 'orange'
    },
    {
      title: 'Active Incidents',
      value: trafficData.incidents.toString(),
      change: trafficData.incidents > 3 ? 'High' : 'Normal',
      icon: Clock,
      color: trafficData.incidents > 3 ? 'red' : 'blue'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Traffic Intelligence Dashboard</h2>
        <div className="text-gray-400">
          Last updated: {currentTime.toLocaleTimeString()}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <TrafficChart />
        </div>
        <div>
          <LiveFeed />
        </div>
      </div>

      {/* ML Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MLInsights />
      </div>
    </div>
  );
}