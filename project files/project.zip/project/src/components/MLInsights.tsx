import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, AlertCircle, Target } from 'lucide-react';

export function MLInsights() {
  const [insights, setInsights] = useState({
    accuracy: 94.2,
    prediction: 'Peak congestion expected at 5:30 PM on I-95 North',
    anomalyScore: 0.23,
    recommendation: 'Recommend alternate routes via Highway 101'
  });

  const [modelStats, setModelStats] = useState({
    processed: 156789,
    accuracy: 94.2,
    latency: 12,
    predictions: 892
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setModelStats(prev => ({
        processed: prev.processed + Math.floor(Math.random() * 100 + 50),
        accuracy: Math.max(90, Math.min(99, prev.accuracy + (Math.random() * 2 - 1))),
        latency: Math.max(5, Math.min(50, prev.latency + (Math.random() * 4 - 2))),
        predictions: prev.predictions + Math.floor(Math.random() * 5 + 1)
      }));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* ML Model Performance */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center space-x-2 mb-4">
          <Brain className="h-6 w-6 text-blue-500" />
          <h3 className="text-lg font-semibold text-white">ML Model Performance</h3>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-400 text-sm">Data Points Processed</p>
              <p className="text-2xl font-bold text-white">{modelStats.processed.toLocaleString()}</p>
            </div>
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-400 text-sm">Model Accuracy</p>
              <p className="text-2xl font-bold text-green-400">{modelStats.accuracy.toFixed(1)}%</p>
            </div>
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-400 text-sm">Avg Latency</p>
              <p className="text-2xl font-bold text-blue-400">{modelStats.latency.toFixed(0)}ms</p>
            </div>
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-400 text-sm">Predictions Today</p>
              <p className="text-2xl font-bold text-purple-400">{modelStats.predictions}</p>
            </div>
          </div>
          
          <div className="bg-gray-700 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">Training Progress</span>
              <span className="text-white text-sm">94%</span>
            </div>
            <div className="w-full bg-gray-600 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: '94%' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Smart Insights */}
      <div className="bg-gray-800 rounded-lg p-6 border border-gray-700">
        <div className="flex items-center space-x-2 mb-4">
          <Target className="h-6 w-6 text-green-500" />
          <h3 className="text-lg font-semibold text-white">Smart Insights</h3>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-start space-x-3 p-3 bg-blue-900/30 border border-blue-700 rounded-lg">
            <TrendingUp className="h-5 w-5 text-blue-400 mt-0.5" />
            <div>
              <p className="text-blue-300 font-medium">Traffic Prediction</p>
              <p className="text-gray-300 text-sm">{insights.prediction}</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-3 bg-orange-900/30 border border-orange-700 rounded-lg">
            <AlertCircle className="h-5 w-5 text-orange-400 mt-0.5" />
            <div>
              <p className="text-orange-300 font-medium">Anomaly Detection</p>
              <p className="text-gray-300 text-sm">Low anomaly score: {insights.anomalyScore} - Normal patterns detected</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-3 bg-green-900/30 border border-green-700 rounded-lg">
            <Target className="h-5 w-5 text-green-400 mt-0.5" />
            <div>
              <p className="text-green-300 font-medium">AI Recommendation</p>
              <p className="text-gray-300 text-sm">{insights.recommendation}</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}